# Curs 1
- Introducere + Overview curs
- Afisare versiune finală a aplicației
- Setup ( visual studio code, git, live server, Git)
- Noțiuni generale
- Class
- Arrow functions
- Async / await
- Destructuring
- Q&A

# Curs 2
- Implementare Grid
- Event Listeners pe celule
- Efectul de play
- Buton de play / reset

# Curs 3
- Exemplu Canvas
- MediaPipe Holistic
( https://google.github.io/mediapipe/solutions/holistic.html)
- Activarea celulelor folosind MediaPipe

# Curs 4
- Gest pentru modificarea BPM-ului
- Invatarea si clasificarea de gesturi
( https://github.com/tensorflow/tfjs-models/tree/master/knn-classifier)
